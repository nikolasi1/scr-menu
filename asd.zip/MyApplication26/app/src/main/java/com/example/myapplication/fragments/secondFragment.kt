package com.example.myapplication.fragments

import androidx.fragment.app.Fragment
import com.example.myapplication.R

class secondFragment :Fragment(R.layout.fragment_second){
}